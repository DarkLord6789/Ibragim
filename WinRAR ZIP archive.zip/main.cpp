#include "Functions.h"

int main() {
	mainFunc();
}