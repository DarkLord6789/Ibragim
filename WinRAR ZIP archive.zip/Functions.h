#pragma once
#include <string>
#include <Windows.h>
#include <fstream>

bool fileExists(const std::string& filePath);
std::string toLower(const std::string& str);
DWORD findProcessId(const std::string& processName);
int getProc(HANDLE* handleToProc, DWORD pid);
int InjectDLL(DWORD PID, const char* dll);
int mainFunc();


